void DAC_Init(uint16_t data);

void DAC_Out(uint16_t code);


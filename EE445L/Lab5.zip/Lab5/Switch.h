void PolledButtons_Init(void);

void GPIOPortE_Handler(void);

void resetSwitches(void);

void Board_Init(void);

void Switch_Init2(void);


//.h file for Clock.c
void DisplayClockDigital(void);
void DisplayClockAnalog(void);

void EdgeCounter_Init(void);


void switchReset(void);

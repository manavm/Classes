void PWM_Duty(unsigned short high)

void PWM_Init(unsigned short period, unsigned short duty)

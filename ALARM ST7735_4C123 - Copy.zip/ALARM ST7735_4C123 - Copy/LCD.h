 void displayAnalog(int hours, int minutes);
 
 void displayDigital(int hours, int minutes, int seconds);
 
 void displayAlarm(int hours, int minutes, int seconds);

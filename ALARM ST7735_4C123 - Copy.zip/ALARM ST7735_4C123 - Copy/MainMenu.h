//these are the functions in the main menu
void RefreshSetTime(void);
void RefreshSetTime2(int);
void SetTime(void);
void SetAlarm(void);
void SetOn_Off(void);
void ChangeDisplayMode(void);

